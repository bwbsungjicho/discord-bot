const eventModel = require('../models/eventSchema');

module.exports = {
	name: 'event',
	aliases: ['events'],
	description: 'viewing an event',
	async execute(client, message, cmd, args, Discord, profileData, eventData) {
	}
}