module.exports = () => {
    console.log("Bot is online!!!");
}