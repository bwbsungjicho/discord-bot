module.exports = () => {
    //a simple message saying that the bot is online
    console.log("Bot is online!!!");
}