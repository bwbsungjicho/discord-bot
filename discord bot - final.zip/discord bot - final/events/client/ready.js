//a simple command that says ready whenever the bot gets logged on
module.exports = () => {
    //a simple message saying that the bot is online
    console.log("Bot is online!!!");
}